﻿
function injectScript(resourcePath, initCode) {
    if (window.document.head === null) {
        window.setTimeout(function () { injectScript(resourcePath, initCode); }, 10);
        return;
    }

    var script = chrome.extension.getURL(resourcePath);
    var el = window.document.createElement('script');
    el.src = script;

    el.onload = function () {
        var loadScript = window.document.createElement('script');
        loadScript.innerHTML = initCode;
        window.document.head.appendChild(loadScript);
    };

    window.document.head.appendChild(el);
}

function injectShadowDomUnlocker() {
    chrome.runtime.sendMessage({ message: "shouldInjectShadowDomUnlocker", url: window.document.URL },
        function (response) {
            if (chrome.runtime.lastError) {
                window.setTimeout(function () { injectShadowDomUnlocker(); }, 10);
                return;
            }

            if (response === undefined || response === null || response.shouldInjectShadowDomUnlocker !== true) {
                window.document.documentElement.setAttribute("toscacontainsshadowdom", "true");
                return;
            }

            injectScript("Resources/shadowDOMUnlocker.js", "var unlocker = new shadowDOMUnlocker();");
        });
}

injectShadowDomUnlocker();

function injectAlertAlerter() {
    chrome.runtime.sendMessage({ method: "getEnableAlertAlerter" }, function (response) {
        if (chrome.runtime.lastError) {
            window.setTimeout(function () { injectAlertAlerter() }, 10);
            return;
        }

        if (response === undefined || response === null || response.enableAlertAlerter !== "true") {
            return;
        }
        injectScript("Resources/alertAlerter.js", "var toscaAlertAlerter = new toscaAlertAlerter();");
    });
}

injectAlertAlerter();
