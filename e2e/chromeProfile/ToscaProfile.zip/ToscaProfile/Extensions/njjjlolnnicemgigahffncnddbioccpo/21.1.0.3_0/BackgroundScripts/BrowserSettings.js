﻿function BrowserSettings() {
    var self = this;
    var settings = readFromLocalStorage("BrowserSettings") || {};

    chrome.runtime.onMessage.addListener(function (request, sender, respond) {
        if (request === undefined || request === null) {
            return;
        }

        if (request.message === "shouldInjectAjaxTracer") {
            respond({ shouldInjectAjaxTracer: shouldInjectAjaxTracer(request.url), ajaxTracerDelay: getAjaxTracerInjectionDelay() });
        }
        else if (request.message === "shouldInjectShadowDomUnlocker") {
            respond({ shouldInjectShadowDomUnlocker: shouldInjectShadowDomUnlocker(request.url) });
        }
        else if (request.message === "setBrowserSettings") {
            respond({ settingsHaveChanged: self.SetSerializedBrowserSettings(request.settings, request.preventReload) });
        }
    });

    self.SetBrowserSettings = function (newSettings, preventReload) {
        if (!deepEquals(newSettings, settings)) {
            settings = newSettings || {};
            writeToLocalStorage("BrowserSettings", settings);

            if (preventReload !== true) {
                reloadAllTabs();
            }
            return true;
        }

        return false;
    }

    self.SetSerializedBrowserSettings = function (newSerializedSettings, preventReload) {
        var newSettings;
        try {
            newSettings = JSON.parse(newSerializedSettings);
        } catch (ex) {
            log("Failed parse settings: " + ex.message, LOG_SEV_ERROR);
            return true;
        }
        if (newSettings === null) {
            return true;
        }

        return self.SetBrowserSettings(newSettings, preventReload);
    }

    function deepEquals(x, y) {
        if (x === y) {
            return true;
        } else if ((typeof x == "object" && x != null) && (typeof y == "object" && y != null)) {
            if (Object.keys(x).length !== Object.keys(y).length) {
                return false;
            }

            for (var prop in x) {
                if (y.hasOwnProperty(prop)) {
                    if (!deepEquals(x[prop], y[prop])) {
                        return false;
                    }
                } else {
                    return false;
                }
            }

            return true;
        } else {
            return false;
        }
    }

    function readFromLocalStorage(key) {
        var jsonValue = localStorage[key];

        if (jsonValue === undefined || jsonValue === null) {
            return null;
        }

        try {
            return JSON.parse(jsonValue);
        } catch (e) {
            log("Could not read " + key + " from local storage: " + e.message, LOG_SEV_ERROR);
            return null;
        }
    }

    function reloadAllTabs() {
        chrome.tabs.query({}, function (tabs) {
            tabs.forEach(function (tab) {
                if (tab.url.startsWith("chrome://")) {
                    return;
                }
                chrome.tabs.reload(tab.id);
            });
        });
    }

    function shouldInjectAjaxTracer(url) {
        if (settings.AjaxBlacklist === undefined || settings.AjaxBlacklist === null) {
            return true;
        }

        if (url === undefined || url === null) {
            return true;
        }

        var ajaxBlacklist = settings.AjaxBlacklist;

        if (ajaxBlacklist !== undefined && ajaxBlacklist !== null) {
            for (var i = 0; i < ajaxBlacklist.length; i++) {
                var excludedRegex;

                try {
                    excludedRegex = new RegExp(ajaxBlacklist[i]);
                } catch (e) {
                    continue;
                }

                if (url.match(excludedRegex)) {
                    return false;
                }
            }
        }
        return true;
    }

    function shouldInjectShadowDomUnlocker(url) {
        if (settings.ShadowDomBlacklist === undefined || settings.ShadowDomBlacklist === null) {
            return true;
        }

        if (url === undefined || url === null) {
            return true;
        }

        var shadowDomBlacklist = settings.ShadowDomBlacklist;

        if (shadowDomBlacklist !== undefined && shadowDomBlacklist !== null) {
            for (var i = 0; i < shadowDomBlacklist.length; i++) {
                var excludedRegex;

                try {
                    excludedRegex = new RegExp(shadowDomBlacklist[i]);
                } catch (e) {
                    continue;
                }

                if (url.match(excludedRegex)) {
                    return false;
                }
            }
        }

        return true;
    }

    function getAjaxTracerInjectionDelay() {
        var setting = getSetting("AjaxTracerTnjectionDelay");
        if (setting === undefined || setting === null) {
            return 0;
        }
        return setting;
    }

    function getSetting(name) {
        if (settings.Settings === undefined || settings.Settings === null) {
            return null;
        }

        var setting = settings.Settings.find(entry => entry.Key === name).Value;
        if (setting) {
            return setting;
        }
        return null;
    }

    function writeToLocalStorage(key, value) {
        var jsonValue;

        try {
            jsonValue = JSON.stringify(value);
        } catch (e) {
            log("Could not write " + key + " to local storage: " + e.message, LOG_SEV_ERROR);
            return;
        }

        localStorage[key] = jsonValue;
    }
}

var browserSettings = new BrowserSettings();
